package model;

public interface Observer {
	public void hienThiTTSP(String nd);
	public void hienThiKM(String nd);
	public void themSP(SanPham sp);
}
