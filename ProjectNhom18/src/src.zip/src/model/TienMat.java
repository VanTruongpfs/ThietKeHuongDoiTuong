package model;

public class TienMat implements PTPAY {

	@Override
	public boolean thanhToan() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double pay() {
		// TODO Auto-generated method stub
		return 0;
	}

}
