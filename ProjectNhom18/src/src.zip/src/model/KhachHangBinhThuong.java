package model;

public class KhachHangBinhThuong extends KhachHang {

	public KhachHangBinhThuong(String maKH, String tenKH, String sdt, String diachi, HoaDon hoadon) {
		super(maKH, tenKH, sdt, diachi, hoadon);
	}

	@Override
	public void hienThiTTSP(String nd) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hienThiKM(String nd) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void themSP(SanPham sp) {
		// TODO Auto-generated method stub
		
	}

}
