package model;

public interface Subject {
	 public void themOB(Observer ob);
	 public void xoaOB(Observer ob);
	 public void thongBaoSPM();
	 public void thongBaoKM();
}
