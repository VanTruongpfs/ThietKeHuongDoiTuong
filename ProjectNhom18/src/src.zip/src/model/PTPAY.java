package model;

public interface PTPAY {
	public boolean thanhToan();
	public double pay();
}
