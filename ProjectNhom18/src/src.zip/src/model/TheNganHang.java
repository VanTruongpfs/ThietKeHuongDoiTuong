package model;

public class TheNganHang implements PTPAY {
	private String maTNH;
	
	public TheNganHang(String maTNH) {
		super();
		this.maTNH = maTNH;
	}

	@Override
	public boolean thanhToan() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double pay() {
		// TODO Auto-generated method stub
		return 0;
	}

}
