package model;

public class ThanhToan {
	private PTPAY phuongThucPay;

	public ThanhToan(PTPAY phuongThucPay) {
		super();
		this.phuongThucPay = phuongThucPay;
	}
	public void setPTTT(PTPAY phuongThucPay) {
		this.phuongThucPay = phuongThucPay;
	}
	
}
