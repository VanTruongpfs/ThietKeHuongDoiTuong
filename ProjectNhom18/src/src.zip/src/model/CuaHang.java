package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import utils.DBConnection;

public class CuaHang implements Subject {
    private String maCH;
    private String tenCH;
    private List<NhanVien> dsNV = new ArrayList<>();
    private List<SanPham> dsSP = new ArrayList<>();
    private List<Observer> dsKH = new ArrayList<>();
    private List<HoaDon> dsHD = new ArrayList<>();

    public CuaHang() {
        layNhanVienTuDB();
        laySPTuDB();
       // layKHTuDB();
    }

    public void layNhanVienTuDB() {
        dsNV.clear();
        try (Connection cnn = DBConnection.getConnection();
             PreparedStatement ps = cnn.prepareStatement("SELECT * FROM NHANVIEN");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                dsNV.add(new NhanVien(
                    rs.getString("maNV"),
                    rs.getString("tenNV"),
                    rs.getDate("ngaySinh"),
                    rs.getDate("ngayBDLam"),
                    rs.getDouble("luongCB"),
                    rs.getInt("soGioLam")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean themNhanVien(NhanVien nv) {
        if (nv == null || dsNV.contains(nv)) {
            return false;
        }
        dsNV.add(nv);
        return true;
    }

    public boolean xoaNhanVien(String maNV) {
        NhanVien nvToRemove = null;
        for (NhanVien nv : dsNV) {
            if (nv.getMaNV().equals(maNV)) {
                nvToRemove = nv;
                break;
            }
        }
        if (nvToRemove != null) {
            dsNV.remove(nvToRemove);
            return true;
        }
        return false;
    }

    public NhanVien timNhanVien(String maNV) {
        for (NhanVien nv : dsNV) {
            if (nv.getMaNV().equals(maNV)) {
                return nv;
            }
        }
        return null;
    }

    public void laySPTuDB() {
        dsSP.clear();
        try (Connection cnn = DBConnection.getConnection();
             PreparedStatement ps = cnn.prepareStatement("SELECT * FROM SANPHAM");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                dsSP.add(new SanPham(
                    rs.getString("maSP"),
                    rs.getString("tenSP"),
                    rs.getDouble("donGia"),
                    rs.getInt("tonKho"),
                    rs.getString("xuatXu")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

/*    public void layKHTuDB() {
        dsKH.clear();
        try (Connection cnn = DBConnection.getConnection();
             PreparedStatement ps = cnn.prepareStatement("SELECT * FROM KHACHHANG");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                dsKH.add(new KhachHangThanThiet(
                    rs.getString("maKH"),
                    rs.getString("tenKH"),
                    rs.getString("sdt"),
                    rs.getString("diaChi"),
                    rs.getBoolean("loaiKH"),
                    rs.getInt("diemTichLuy")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
*/
    public List<NhanVien> getDsNV() {
        return dsNV;
    }

    public List<SanPham> getDsSP() {
        return dsSP;
    }

    public List<Observer> getDsKH() {
        return dsKH;
    }

    public List<HoaDon> getDsHD() {
        return dsHD;
    }

	@Override
	public void themOB(Observer ob) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void xoaOB(Observer ob) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void thongBaoSPM() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void thongBaoKM() {
		// TODO Auto-generated method stub
		
	}
	public boolean insertNhanVien(NhanVien nv) {
	    if (nv == null) {
	        System.out.println("Nhân viên không hợp lệ!");
	        return false;
	    }

	    try (Connection cnn = DBConnection.getConnection();
	         PreparedStatement ps = cnn.prepareStatement("INSERT INTO NHANVIEN (maNV, tenNV, ngaySinh, ngayBDLam, luongCB, soGioLam) VALUES (?, ?, ?, ?, ?, ?)")) {

	        ps.setString(1, nv.getMaNV());
	        ps.setString(2, nv.getTenNV());
	        ps.setDate(3, nv.getNgaySinh());
	        ps.setDate(4, nv.getNgayBDLam());
	        ps.setDouble(5, nv.getLuongCB());
	        ps.setInt(6, nv.getSoGioLam());

	        int result = ps.executeUpdate();
	        return result > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	    }
	
}
