package quanlicuahang;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.plaf.SplitPaneUI;
import javax.swing.table.DefaultTableModel;

public class GiaoDienChinh extends JFrame {
	JPanel pnTaoDon, pnQuanLyHoaDon, pnQuanLyNhanVien, pnQuanLySanPham, pnQuanLyKhachHang;
	JMenuBar menubar;
	JMenu mnHoaDon, mnQuanLiHeThong;
	JMenuItem mniQuanLyHoaDon, mniQuanLySanPham, mniQuanLyNhanVien, mniQuanLiKhachHang;
	CardLayout cardLayout;
	// các thành phần của tạo đơn
	JSplitPane splitPaneTD;
	JPanel pnTraiTD, pnPhaiTD, pnThanhToan, pnThongTin, pnThaoTac, ptPanel, pnNut;
	JTextField tfMaHD, tfNgayLap, tfSDT, tfTongTien, tfTienKhach;
	JTable tblChiTiet, tblMenu;
	DefaultTableModel modelChiTiet;
	JRadioButton rdTienMat, rdChuyenKhoan, rdTheNganHang;
	ButtonGroup bgPTTT;
	JButton btnHuy, btnXuat, btnTimKiemTD, btnThemSP, btnXoaSP;
	JTextField tfTimKiemTD;
	JLabel lblMaHD, lblNgayLap, lblTongTien, lblPTTT, lblTenNV, lblTienKhach, lblSDT;
	String[] tenNV, khoSP;
	JComboBox<String> cbTenNV;
	JScrollPane scrollMenu, scrollChiTiet;
	// các thành phần của khách hàng
	JPanel pnTrai, pnPhai, pnTren, pnDuoi, pnDuoiTrai, pnD, formPanel, pnTimKiem;
	JButton btnThem, btnXoa, btnSua, btnTim;
	JLabel titleLabel;
	JTextField txtMaKH, txtTenKH, txtDiaChi, txtSDT, txtDiem, tfTimKiem;
	JComboBox<String> cboGioiTinh;
	DefaultTableModel modelKH;
	JTable tblKH;
	JScrollPane scrollKH;
	JSplitPane splitPane;
	// các thành phần của sản phẩm
	JPanel quanLiSanPHam,panelSearch,panelBangThongTinSP,panelBangThongTinSP1,panelBangThongTinSP2
		,pnADDRe1,pnADDRe12,panelQlFunction,pnADDRe11,pnADDRe2,pnADDRe21,pnADDRe22;
	JButton bSave, add, remove, nutSerach;
	JTextField textMaSP, textMaSP_Xoa, textTenSP, textSLSP, textGiaSP, textAnhSP,boxSearch;
	JTable tableBangThongTinSP;
	JScrollPane scrollThongTinSP;
	// nhân viên
	JPanel panelQLNV_Main, panelQLNV_TimKiem, panelQLNV_Trai, panelQLNV_FormThem, panelQLNV_BtnThem, panelQLNV_Xoa,
			panelQLNV_Phai;
	JTextField tfQLNV_MaTK, tfQLNV_MaNV, tfQLNV_TenNV, tfQLNV_NgaySinh, tfQLNV_GioiTinh, tfQLNV_DiaChi, tfQLNV_SDT,
			tfQLNV_ChucVu, tfQLNV_Luong, tfQLNV_XoaMaNV;
	JButton btnQLNV_Tim, btnQLNV_Them, btnQLNV_Xoa;
	JLabel lblQLNV_MaTK;
	JTable tblQLNV;
	DefaultTableModel modelQLNV;
	JScrollPane scrollQLNV;
	JSplitPane splitPaneQLNV;
	// hóa đơn
    JPanel pnHD,leftPanelHD, rigthPanelHD, sreachPanelHD,bottomLeftPanelHD,dateFilterPanelHD,leftPanel,rightPanel,searchPanel,dateFilterPanel;
    JTextField searchField,txtDoanhThu,tfNgay,tfThang,tfNam;
    JComboBox<String> filterBox;
    JLabel searchLabelHD,searchLabel;
    JLabel labelHD;
    JButton statsButton,searchButton,btnLocTheoNgay,btnThongKe;
    JLabel lblNgay, lblThang,lblNam;
    JSplitPane splitPaneHD;
    JTable table;
    DefaultTableModel model;

	public GiaoDienChinh() {
		setTitle("Quản lý cửa hàng");
		setSize(1000, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// CardLayout cho content pane
		cardLayout = new CardLayout();
		getContentPane().setLayout(cardLayout);

		// Tạo menu
		menubar = new JMenuBar();
		mnHoaDon = new JMenu("Tạo hóa đơn");
		mnQuanLiHeThong = new JMenu("Chức năng quản lý");

		menubar.add(mnHoaDon);
		menubar.add(mnQuanLiHeThong);
		// menu item
		mniQuanLyHoaDon = new JMenuItem("Quản lý hóa đơn");
		mniQuanLyNhanVien = new JMenuItem("Quản lý nhân viên");
		mniQuanLySanPham = new JMenuItem("Quản lý sản phẩm");
		mniQuanLiKhachHang = new JMenuItem("Quản lý khách hàng");
		mnQuanLiHeThong.add(mniQuanLyHoaDon);
		mnQuanLiHeThong.add(mniQuanLySanPham);
		mnQuanLiHeThong.add(mniQuanLyNhanVien);
		mnQuanLiHeThong.add(mniQuanLiKhachHang);
		setJMenuBar(menubar);

		// Tạo các panel
		pnTaoDon = new JPanel(new BorderLayout());
		taoGiaoDienTaoDon();

		pnQuanLyHoaDon = new JPanel();
		pnQuanLyHoaDon.add(new JLabel("Quản lý hóa đơn"));
		taoQuanLyHoaDon();
		pnQuanLyNhanVien = new JPanel();
		pnQuanLyNhanVien.add(new JLabel("Quản lý nhân viên"));
		taoGiaoDienQuanLyNhanVien();

		pnQuanLySanPham = new JPanel();
		pnQuanLySanPham.add(new JLabel("Quản lý sản phẩm"));
		taoQuanLySanPham();
		pnQuanLyKhachHang = new JPanel();
		pnQuanLyKhachHang.add(new JLabel("Quản lý khách hàng"));
		taoGiaoDienQuanLyKhachHang();

		getContentPane().add(pnQuanLyHoaDon, "QLHoaDon");
		getContentPane().add(pnQuanLyNhanVien, "QLNhanVien");
		getContentPane().add(pnQuanLySanPham, "QLSanPham");
		getContentPane().add(pnQuanLyKhachHang, "QLKhachHang");

		// Thêm các panel vào CardLayout
		getContentPane().add(pnTaoDon, "TaoDon");
		cardLayout.show(getContentPane(), "TaoDon");

		// Thêm sự kiện chuyển layout
		mnHoaDon.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				cardLayout.show(getContentPane(), "TaoDon");
			}
		});

		mniQuanLyHoaDon.addActionListener(e -> cardLayout.show(getContentPane(), "QLHoaDon"));
		mniQuanLyNhanVien.addActionListener(e -> cardLayout.show(getContentPane(), "QLNhanVien"));
		mniQuanLySanPham.addActionListener(e -> cardLayout.show(getContentPane(), "QLSanPham"));
		mniQuanLiKhachHang.addActionListener(e -> cardLayout.show(getContentPane(), "QLKhachHang"));
		setLocationRelativeTo(null);
		setVisible(true);
	}

	// Giao diện tạo hóa đơn
	private void taoGiaoDienTaoDon() {
		// Panel chính chứa bên trái và phải
		splitPaneTD = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		splitPaneTD.setResizeWeight(0.4);

		// === Panel trái: Form hóa đơn ===
		pnTraiTD = new JPanel(new BorderLayout());
		pnThongTin = new JPanel(new GridLayout(4, 2, 10, 10));
		pnThongTin.setBorder(BorderFactory.createTitledBorder("HÓA ĐƠN BÁN LẺ"));

		// Các trường nhập liệu (tạo trước)
		lblMaHD = new JLabel("Mã hóa đơn");
		tfMaHD = new JTextField("HD002");

		lblNgayLap = new JLabel("Ngày lập hóa đơn");
		LocalDate date = LocalDate.now();
		tfNgayLap = new JTextField(date.getDayOfMonth() + "/" + date.getMonthValue() + "/" + date.getYear());

		lblTenNV = new JLabel("Tên nhân viên");
		String[] tenNV = { "Lê Vân Trường", "Lê Hữu Phước", "Nguyễn Gia Huy", "Trương Cao Đoàn", "Trần Nguyễn Thanh Tú",
				"Nguyễn Trọng Tín" };
		cbTenNV = new JComboBox<>(tenNV);

		lblSDT = new JLabel("SDT khách hàng");
		tfSDT = new JTextField();

		// Thêm vào panel thông tin
		pnThongTin.add(lblMaHD);
		pnThongTin.add(tfMaHD);
		pnThongTin.add(lblNgayLap);
		pnThongTin.add(tfNgayLap);
		pnThongTin.add(lblTenNV);
		pnThongTin.add(cbTenNV);
		pnThongTin.add(lblSDT);
		pnThongTin.add(tfSDT);

		// Bảng chi tiết món
		String[] khoSP = { "TÊN MÓN", "SỐ LƯỢNG", "ĐƠN GIÁ", "THÀNH TIỀN" };
		modelChiTiet = new DefaultTableModel(khoSP, 0);
		tblChiTiet = new JTable(modelChiTiet);
		scrollChiTiet = new JScrollPane(tblChiTiet);

		// Panel thanh toán
		pnThanhToan = new JPanel(new GridLayout(3, 2));
		pnThanhToan.setBorder(BorderFactory.createTitledBorder("Thanh toán"));

		lblTongTien = new JLabel("Tổng tiền");
		tfTongTien = new JTextField();

		lblPTTT = new JLabel("PTTT");
		rdTienMat = new JRadioButton("Tiền mặt");
		rdChuyenKhoan = new JRadioButton("Chuyển khoản");
		rdTheNganHang = new JRadioButton("Thẻ NH");
		bgPTTT = new ButtonGroup();
		bgPTTT.add(rdTienMat);
		bgPTTT.add(rdChuyenKhoan);
		bgPTTT.add(rdTheNganHang);
		ptPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		ptPanel.add(rdTienMat);
		ptPanel.add(rdChuyenKhoan);
		ptPanel.add(rdTheNganHang);

		lblTienKhach = new JLabel("Tiền khách đưa");
		tfTienKhach = new JTextField();

		pnThanhToan.add(lblTongTien);
		pnThanhToan.add(tfTongTien);
		pnThanhToan.add(lblPTTT);
		pnThanhToan.add(ptPanel);
		pnThanhToan.add(lblTienKhach);
		pnThanhToan.add(tfTienKhach);

		// Nút thao tác
		btnHuy = new JButton("Hủy hóa đơn");
		btnXuat = new JButton("Xuất hóa đơn");
		pnNut = new JPanel(new FlowLayout(FlowLayout.CENTER));
		pnNut.add(btnHuy);
		pnNut.add(btnXuat);

		// Gắn vào trái
		pnTraiTD.add(pnThongTin, BorderLayout.NORTH);
		pnTraiTD.add(scrollChiTiet, BorderLayout.CENTER);

		pnDuoiTrai = new JPanel(new BorderLayout());
		pnDuoiTrai.add(pnThanhToan, BorderLayout.CENTER);
		pnDuoiTrai.add(pnNut, BorderLayout.SOUTH);
		pnTraiTD.add(pnDuoiTrai, BorderLayout.SOUTH);

		// === Panel phải: MENU BAR ===
		pnPhaiTD = new JPanel(new BorderLayout());
		pnPhaiTD.setBorder(BorderFactory.createTitledBorder("MENU BAR"));

		String[] cols = { "Tên món", "Ảnh", "Giá", "Số lượng còn lại" };
		Object[][] data = { { "OSHI KHOAI TÂY", ".....", 25000.0, 10 }, { "SỮA VINAMILk", ".........", 30000.0, 100 },
				{ "Xà bông", ".........", 45000.0, 20 }, { "Búa", ".........", 45000.0, 49 },
				{ "Dao", "...........", 36000.0, 21 }, { "Pin", "..............", 35000.0, 30 } };
		tblMenu = new JTable(new DefaultTableModel(data, cols));
		scrollMenu = new JScrollPane(tblMenu);

		tfTimKiem = new JTextField();
		btnTim = new JButton("Tìm Kiếm");
		pnTimKiem = new JPanel(new BorderLayout());
		pnTimKiem.add(tfTimKiem, BorderLayout.CENTER);
		pnTimKiem.add(btnTim, BorderLayout.EAST);

		btnThemSP = new JButton("Thêm sản phẩm");
		btnXoaSP = new JButton("Xóa sản phẩm");
		pnThaoTac = new JPanel();
		pnThaoTac.add(btnThemSP);
		pnThaoTac.add(btnXoaSP);

		pnPhaiTD.add(pnTimKiem, BorderLayout.NORTH);
		pnPhaiTD.add(scrollMenu, BorderLayout.CENTER);
		pnPhaiTD.add(pnThaoTac, BorderLayout.SOUTH);

		// Gắn vào SplitPane
		splitPaneTD.setLeftComponent(pnTraiTD);
		splitPaneTD.setRightComponent(pnPhaiTD);

		pnTaoDon.removeAll();
		pnTaoDon.add(splitPaneTD, BorderLayout.CENTER);
		pnTaoDon.revalidate();
		pnTaoDon.repaint();
	}

// tạo giao diện quản lý khách hàng
	private void taoGiaoDienQuanLyKhachHang() {
		pnQuanLyKhachHang.setLayout(new BorderLayout());
		// Panel bên trái
		pnTrai = new JPanel();
		pnTrai.setLayout(new BoxLayout(pnTrai, BoxLayout.Y_AXIS));
		pnTrai.setBorder(BorderFactory.createTitledBorder("QUẢN LÍ KHÁCH HÀNG"));

		btnThem = new JButton("Thêm khách hàng");
		btnXoa = new JButton("Xóa khách hàng");
		btnSua = new JButton("Sửa khách hàng");

		// Tạo panel chứa các ô nhập liệu theo dạng bảng
		formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
		formPanel.setBorder(BorderFactory.createTitledBorder("Thêm khách hàng"));
		// Các ô nhập liệu
		txtMaKH = new JTextField();
		txtTenKH = new JTextField();
		cboGioiTinh = new JComboBox<>(new String[] { "Nam", "Nữ" });
		txtDiaChi = new JTextField();
		txtSDT = new JTextField();
		txtDiem = new JTextField();

		// Thêm vào form
		formPanel.add(new JLabel("Mã khách hàng:"));
		formPanel.add(txtMaKH);

		formPanel.add(new JLabel("Tên khách hàng:"));
		formPanel.add(txtTenKH);

		formPanel.add(new JLabel("Số điện thoại:"));
		formPanel.add(txtSDT);

		formPanel.add(new JLabel("Giới tính:"));
		formPanel.add(cboGioiTinh);

		formPanel.add(new JLabel("Địa chỉ:"));
		formPanel.add(txtDiaChi);

		formPanel.add(new JLabel("Điểm"));
		formPanel.add(txtDiem);
		pnTrai.add(formPanel, BorderLayout.NORTH);
		pnTrai.add(Box.createVerticalStrut(30));

		pnDuoi = new JPanel();
		pnDuoi.setLayout(new FlowLayout());
		pnDuoi.add(btnThem);
		pnDuoi.add(btnXoa);
		pnDuoi.add(btnSua);

		pnTrai.add(pnDuoi, BorderLayout.CENTER);

		// Panel bên phải (tìm kiếm + bảng)
		pnPhai = new JPanel(new BorderLayout());

		pnTimKiem = new JPanel(new BorderLayout());
		tfTimKiem = new JTextField();
		btnTim = new JButton("Tìm");
		pnTimKiem.add(new JLabel("Nhập thông tin cần tìm: "), BorderLayout.WEST);
		pnTimKiem.add(tfTimKiem, BorderLayout.CENTER);
		pnTimKiem.add(btnTim, BorderLayout.EAST);

		String[] cols = { "Mã KH", "Tên khách hàng", "Số điện thoại", "Giới tính", "Địa chỉ", "Điểm tích lũy" };
		modelKH = new DefaultTableModel(cols, 0);
		tblKH = new JTable(modelKH);
		scrollKH = new JScrollPane(tblKH);

		pnPhai.add(pnTimKiem, BorderLayout.NORTH);
		pnPhai.add(scrollKH, BorderLayout.CENTER);

		splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, pnTrai, pnPhai);
		splitPane.setDividerLocation(450);
		splitPane.setResizeWeight(0.1);
		pnQuanLyKhachHang.removeAll();
		pnQuanLyKhachHang.add(splitPane, BorderLayout.CENTER);
		pnQuanLyKhachHang.revalidate();
		pnQuanLyKhachHang.repaint();
	}

	// giao diện quản lí nhân viên
	private void taoGiaoDienQuanLyNhanVien() {
		pnQuanLyNhanVien.removeAll();
		pnQuanLyNhanVien.setLayout(new BorderLayout());

		panelQLNV_Main = new JPanel(new BorderLayout());
		panelQLNV_Main.setBorder(BorderFactory.createTitledBorder("Quản Lí Nhân Viên"));

		// ========== KHU VỰC TÌM KIẾM NHÂN VIÊN ==========
		panelQLNV_TimKiem = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelQLNV_TimKiem.setBorder(BorderFactory.createTitledBorder("Tìm kiếm nhân viên"));

		lblQLNV_MaTK = new JLabel("Mã nhân viên: ");
		tfQLNV_MaTK = new JTextField(15);
		btnQLNV_Tim = new JButton("Tìm");

		panelQLNV_TimKiem.add(lblQLNV_MaTK);
		panelQLNV_TimKiem.add(tfQLNV_MaTK);
		panelQLNV_TimKiem.add(btnQLNV_Tim);

		panelQLNV_Main.add(panelQLNV_TimKiem, BorderLayout.NORTH);

		// ========== KHU VỰC TRÁI ==========
		panelQLNV_Trai = new JPanel(new BorderLayout());

		// ---- FORM THÊM NHÂN VIÊN ----
		panelQLNV_FormThem = new JPanel(new GridLayout(8, 2));
		panelQLNV_FormThem.setBorder(BorderFactory.createTitledBorder("Thêm nhân viên"));

		tfQLNV_MaNV = new JTextField();
		tfQLNV_TenNV = new JTextField();
		tfQLNV_NgaySinh = new JTextField();
		tfQLNV_GioiTinh = new JTextField();
		tfQLNV_DiaChi = new JTextField();
		tfQLNV_SDT = new JTextField();
		tfQLNV_ChucVu = new JTextField();
		tfQLNV_Luong = new JTextField();

		panelQLNV_FormThem.add(new JLabel("Mã nhân viên:"));
		panelQLNV_FormThem.add(tfQLNV_MaNV);
		panelQLNV_FormThem.add(new JLabel("Tên nhân viên:"));
		panelQLNV_FormThem.add(tfQLNV_TenNV);
		panelQLNV_FormThem.add(new JLabel("Ngày sinh:"));
		panelQLNV_FormThem.add(tfQLNV_NgaySinh);
		panelQLNV_FormThem.add(new JLabel("Giới tính:"));
		panelQLNV_FormThem.add(tfQLNV_GioiTinh);
		panelQLNV_FormThem.add(new JLabel("Địa chỉ:"));
		panelQLNV_FormThem.add(tfQLNV_DiaChi);
		panelQLNV_FormThem.add(new JLabel("Số điện thoại:"));
		panelQLNV_FormThem.add(tfQLNV_SDT);
		panelQLNV_FormThem.add(new JLabel("Chức vụ:"));
		panelQLNV_FormThem.add(tfQLNV_ChucVu);
		panelQLNV_FormThem.add(new JLabel("Lương:"));
		panelQLNV_FormThem.add(tfQLNV_Luong);

		btnQLNV_Them = new JButton("Thêm nhân viên");
		panelQLNV_BtnThem = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelQLNV_BtnThem.add(btnQLNV_Them);

		JPanel panelQLNV_ThemNV = new JPanel(new BorderLayout());
		panelQLNV_ThemNV.add(panelQLNV_FormThem, BorderLayout.NORTH);
		panelQLNV_ThemNV.add(panelQLNV_BtnThem, BorderLayout.CENTER);

		panelQLNV_Trai.add(panelQLNV_ThemNV, BorderLayout.NORTH);

		// ---- FORM XÓA NHÂN VIÊN ----
		panelQLNV_Xoa = new JPanel(new BorderLayout());
		panelQLNV_Xoa.setBorder(BorderFactory.createTitledBorder("Xóa nhân viên"));

		tfQLNV_XoaMaNV = new JTextField();
		btnQLNV_Xoa = new JButton("Xóa");

		panelQLNV_Xoa.add(new JLabel("Mã nhân viên:"), BorderLayout.NORTH);
		panelQLNV_Xoa.add(tfQLNV_XoaMaNV, BorderLayout.CENTER);
		panelQLNV_Xoa.add(btnQLNV_Xoa, BorderLayout.SOUTH);

		panelQLNV_Trai.add(panelQLNV_Xoa, BorderLayout.SOUTH);

		// ========== KHU VỰC PHẢI ==========
		panelQLNV_Phai = new JPanel(new BorderLayout());
		panelQLNV_Phai.setBorder(BorderFactory.createTitledBorder("Danh sách nhân viên"));

		String[] cols = { "Mã NV", "Tên NV", "Ngày sinh", "Giới tính", "Địa chỉ", "SĐT", "Chức vụ", "Lương" };
		modelQLNV = new DefaultTableModel(cols, 0);
		tblQLNV = new JTable(modelQLNV);
		scrollQLNV = new JScrollPane(tblQLNV);

		panelQLNV_Phai.add(scrollQLNV, BorderLayout.CENTER);

		// ========== GỘP TRÁI - PHẢI ==========
		splitPaneQLNV = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelQLNV_Trai, panelQLNV_Phai);
		splitPaneQLNV.setResizeWeight(0.4);

		panelQLNV_Main.add(splitPaneQLNV, BorderLayout.CENTER);
		pnQuanLyNhanVien.add(panelQLNV_Main);

		pnQuanLyNhanVien.revalidate();
		pnQuanLyNhanVien.repaint();
	}

// giao diện quản lý sản phẩm
	public void taoQuanLySanPham() {
		// các nút là text field
		bSave = new JButton("Lưu");
		add = new JButton("Thêm");
		remove = new JButton("Xóa");
		textMaSP = new JTextField(10);
		textMaSP_Xoa = new JTextField(10);
		textTenSP = new JTextField(10);
		textSLSP = new JTextField(10);
		textGiaSP = new JTextField(10);
		textAnhSP = new JTextField(10);
		nutSerach = new JButton("Tìm kiếm");
		//
		//
		quanLiSanPHam = new JPanel();
		quanLiSanPHam.setPreferredSize(new Dimension(975, 550));
		quanLiSanPHam.setLayout(new BorderLayout());
		quanLiSanPHam.setBorder(BorderFactory.createTitledBorder("Quản lí sản phẩm"));
		// thanh tiềm kiếm sản phẩm
		panelSearch = new JPanel();
		panelSearch.setLayout(new FlowLayout());
		panelSearch.setBorder(BorderFactory.createTitledBorder("Tìm kiếm sản phẩm"));
		boxSearch = new JTextField(20);
		panelSearch.add(boxSearch);
		panelSearch.add(nutSerach);

		quanLiSanPHam.add(panelSearch, BorderLayout.NORTH);

		// bảng thông tin các loại sản phẩm toàn kho;
		panelBangThongTinSP = new JPanel();
		panelBangThongTinSP.setLayout(new BorderLayout());
		quanLiSanPHam.add(panelBangThongTinSP, BorderLayout.CENTER);

		panelBangThongTinSP1 = new JPanel();
		panelBangThongTinSP.setLayout(new BorderLayout());
		panelBangThongTinSP.add(panelBangThongTinSP1, BorderLayout.CENTER);
		panelBangThongTinSP.setBorder(BorderFactory.createTitledBorder("Thông tin các loại sản phẩm"));
		String[] thongtinCacCot = { "Mã Sản Phẩm", "Tên Sản Phẩm", "Số lượng Tồn Kho", "Giá Niêm Yết", "Hình ảnh" };
		String[][] data = { { "0011", "Coca", "1000", "10000", "Chưa cập nhật" } };
		// không cho chỉnh sửa cột mã
		DefaultTableModel ttCOT = new DefaultTableModel(data, thongtinCacCot) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return column != 0;
			}
		};
		tableBangThongTinSP = new JTable(ttCOT);
		scrollThongTinSP = new JScrollPane(tableBangThongTinSP);
		panelBangThongTinSP1.add(scrollThongTinSP);

		//
		panelBangThongTinSP2 = new JPanel();
		panelBangThongTinSP2.setLayout(new FlowLayout());
		panelBangThongTinSP.add(panelBangThongTinSP2, BorderLayout.SOUTH);
		panelBangThongTinSP2.add(bSave);

		// bảng quản lí chức năng sản phẩm
		panelQlFunction = new JPanel();
		panelQlFunction.setLayout(new BoxLayout(panelQlFunction, BoxLayout.Y_AXIS));
		quanLiSanPHam.add(panelQlFunction, BorderLayout.WEST);

		//
		pnADDRe1 = new JPanel();
		pnADDRe1.setLayout(new GridLayout(2, 1));
		pnADDRe1.setBorder(BorderFactory.createTitledBorder("Thêm Sản Phẩm"));
		panelQlFunction.add(pnADDRe1);

		pnADDRe11 = new JPanel();
		pnADDRe11.setLayout(new GridLayout(5, 2));
		pnADDRe1.add(pnADDRe11);
		pnADDRe11.add(new JLabel("Mã Sản Phẩm:"));
		pnADDRe11.add(textMaSP);
		pnADDRe11.add(new JLabel("Tên Sản Phẩm:"));
		pnADDRe11.add(textTenSP);
		pnADDRe11.add(new JLabel("Số Lượng:"));
		pnADDRe11.add(textSLSP);
		pnADDRe11.add(new JLabel("Giá Sản Phẩm:"));
		pnADDRe11.add(textGiaSP);
		pnADDRe11.add(new JLabel("Ảnh Sản Phẩm:"));
		pnADDRe11.add(textAnhSP);

		pnADDRe12 = new JPanel();
		pnADDRe12.setLayout(new FlowLayout());
		pnADDRe1.add(pnADDRe12);
		pnADDRe12.add(add);
		//
		pnADDRe2 = new JPanel();
		pnADDRe2.setLayout(new GridLayout(2, 1));
		pnADDRe2.setBorder(BorderFactory.createTitledBorder("Xóa Sản Phẩm"));
		panelQlFunction.add(pnADDRe2);

		pnADDRe21 = new JPanel();
		pnADDRe21.setLayout(new GridLayout(2, 1));
		pnADDRe2.add(pnADDRe21);
		pnADDRe21.add(new JLabel("Mã Sản Phẩm:"));
		pnADDRe21.add(textMaSP_Xoa);

		pnADDRe22 = new JPanel();
		pnADDRe22.setLayout(new FlowLayout());
		pnADDRe2.add(pnADDRe22);
		pnADDRe22.add(remove);
		//
		pnQuanLySanPham.removeAll();
		pnQuanLySanPham.add(quanLiSanPHam, BorderLayout.CENTER);
		pnQuanLySanPham.revalidate();
		pnQuanLySanPham.repaint();
		//
	}
//giao diện quản lý hóa đơn
private void taoQuanLyHoaDon() {
	 pnHD = new JPanel(new BorderLayout());
    // ===== Panel bên trái =====
    leftPanel = new JPanel();
    leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
    leftPanel.setPreferredSize(new Dimension(200, 0)); // Chiều rộng cố định
    leftPanel.setMaximumSize(new Dimension(200, Integer.MAX_VALUE));
    leftPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    titleLabel = new JLabel("QUẢN LÝ HÓA ĐƠN");
    titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
    titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

    filterBox = new JComboBox<>(new String[] { "-- Mặc định --", "Theo ngày", "Theo tháng", "Theo năm" });
    filterBox.setMaximumSize(new Dimension(180, 30));
    filterBox.setAlignmentX(Component.CENTER_ALIGNMENT);

    statsButton = new JButton("Chi tiết hóa đơn");
    statsButton.setAlignmentX(Component.CENTER_ALIGNMENT);

    leftPanel.add(Box.createVerticalStrut(20));
    leftPanel.add(titleLabel);
    leftPanel.add(Box.createVerticalStrut(15));
    leftPanel.add(filterBox);
    leftPanel.add(Box.createVerticalStrut(15));
    leftPanel.add(statsButton);

    // ===== Panel bên phải =====
    rightPanel = new JPanel(new BorderLayout());

    searchPanel = new JPanel(new BorderLayout());
    searchLabel = new JLabel("Nhập thông tin cần tìm: ");
    searchField = new JTextField();
    searchButton = new JButton("Tìm");

    searchPanel.add(searchLabel, BorderLayout.WEST);
    searchPanel.add(searchField, BorderLayout.CENTER);
    searchPanel.add(searchButton, BorderLayout.EAST);
    searchPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    String[] columns = { "Mã HD", "Thời gian lập", "Mã NV", "Tên NV", "Tổng tiền", "Tiền khách đưa", "Tiền thừa", "PT Thanh toán" };
    model = new DefaultTableModel(columns, 0);
    table = new JTable(model);
    table.setFillsViewportHeight(true);
    JScrollPane tableScrollPane = new JScrollPane(table);

    rightPanel.add(searchPanel, BorderLayout.NORTH);
    rightPanel.add(tableScrollPane, BorderLayout.CENTER);

    // ===== JSplitPane cho layout trái - phải =====
    splitPaneHD = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
    splitPaneHD.setDividerLocation(200);            // panel trái chiếm 200px
    splitPaneHD.setResizeWeight(0);                 // panel phải chiếm hết phần còn lại
    splitPaneHD.setOneTouchExpandable(true);        // cho phép ẩn/hiện panel trái

    pnHD.add(splitPaneHD, BorderLayout.CENTER);

    populateDummyData();
 // ===== Panel thống kê doanh thu (góc dưới bên trái) =====
    JPanel bottomLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JButton btnThongKe = new JButton("Thống kê doanh thu");
    JTextField txtDoanhThu = new JTextField(15);
    txtDoanhThu.setEditable(false);
    txtDoanhThu.setText("0đ");

    bottomLeftPanel.add(btnThongKe);
    bottomLeftPanel.add(txtDoanhThu);

    // Thêm panel này vào phía dưới cùng của pnHD
    pnHD.add(bottomLeftPanel, BorderLayout.SOUTH);
 // ===== Thanh tìm kiếm hóa đơn theo ngày/tháng/năm =====
    dateFilterPanel = new JPanel();
    dateFilterPanel.setLayout(new GridLayout(4, 1, 5, 5)); // 2 hàng, 4 cột
    dateFilterPanel.setMaximumSize(new Dimension(180, 120));

     lblNgay = new JLabel("Ngày:");
     lblThang = new JLabel("Tháng:");
     lblNam = new JLabel("Năm:");

    tfNgay = new JTextField();
    tfThang = new JTextField();
    tfNam = new JTextField();
    JButton btnLocTheoNgay = new JButton("Lọc");
    dateFilterPanel.add(lblNgay);
    dateFilterPanel.add(tfNgay);
    dateFilterPanel.add(lblThang);
    dateFilterPanel.add(tfThang);
    dateFilterPanel.add(lblNam);
    dateFilterPanel.add(tfNam);
    dateFilterPanel.add(new JLabel()); // ô trống
    dateFilterPanel.add(btnLocTheoNgay);

    leftPanel.add(Box.createVerticalStrut(20));
    leftPanel.add(dateFilterPanel);
    // ===== Gắn vào panel chính =====
    pnQuanLyHoaDon.removeAll();
    pnQuanLyHoaDon.setLayout(new BorderLayout());
    pnQuanLyHoaDon.add(pnHD, BorderLayout.CENTER);
    pnQuanLyHoaDon.revalidate();
    pnQuanLyHoaDon.repaint();
}
private void populateDummyData() {
    String[][] data = {
            {"HD001", "01-01-2024", "NV001", " Hữu Phước", "150,000đ", "200,000đ", "50,000đ", "Tiền mặt"},
            {"HD002", "01-01-2024", "NV002", "Gia Huy", "200,000đ", "200,000đ", "0đ", "Chuyển khoản"},
            {"HD003", "02-01-2024", "NV001", "Vân Trường", "100,000đ", "100,000đ", "0đ", "Tiền mặt"},
            {"HD004", "03-01-2024", "NV003", "Thanh Tú", "250,000đ", "300,000đ", "50,000đ", "Chuyển khoản"},
            {"HD005", "04-01-2024", "NV004", "Cao Đoàn", "120,000đ", "150,000đ", "30,000đ", "Tiền mặt"},
    };
    for (String[] row : data) {
        model.addRow(row);
    }
}
	public static void main(String[] args) {
		new GiaoDienChinh();
	}
}
