package Controller;

import model.CuaHang;
import view.MainView;
import view.TaoHoaDonView;

public class TaoHoaDonController {
	private TaoHoaDonView view;
	private CuaHang model;
	public TaoHoaDonController(TaoHoaDonView view, CuaHang model) {
		this.view = view;
		this.model = model;
		initController();
	}
	 private void initController() {
	      view.getBtnHuy().addActionListener(e -> huyHoaDon());
	    
	 }
	 private void huyHoaDon() {
	        System.out.println("Đã hủy hóa đơn");
	 }
}
