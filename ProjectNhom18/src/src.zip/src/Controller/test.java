package Controller;

import view.QLNVView;

public class test {
public static void main(String[] args) {
	QLNVView view = new QLNVView();
	view.tfQLNV_Luong.setText("15000");
	System.out.println(view.tfQLNV_Luong.getText());
}
}
