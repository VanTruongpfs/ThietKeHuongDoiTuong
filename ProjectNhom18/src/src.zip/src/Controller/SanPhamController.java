package Controller;
import model.CuaHang;
import model.SanPham;
import utils.DBConnection;
import view.QLSanPhamView;
import view.TaoHoaDonView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SanPhamController {
   private QLSanPhamView view;
   private TaoHoaDonView tao = new TaoHoaDonView();
   private CuaHang model;
public SanPhamController(QLSanPhamView view, CuaHang model) {
	super();
	this.view = view;
	this.model = model;
	
	initController();
}

   private void initController() {
//	   view.getbSave().addActionListener(e -> save());
	   view.getbSave().addActionListener(e -> themSP());

   }
	public void save() {
		System.out.println("Đã save");
	}
	
	public void themSP() {
		List<SanPham> ds = new ArrayList<SanPham>();
		ds.add(new SanPham("SP002", "Mì tôm Hảo Hảo", 4500, 300, "Việt Nam"));
		for (SanPham sanPham : ds) {
			String[] tt = { sanPham.getMaSP(),sanPham.getTenSP(), sanPham.getTonKho()+"", sanPham.getDonGia()+"",
					 sanPham.getXuatXu()};
			view.getTtCOT().addRow(tt);
	}
	}
}
